<?php
/**
 * Optional Polylang integration.
 */

function restatify_register_polylang_strings() {
    if (!function_exists('pll_register_string')) {
        return;
    }

    $strings = [
        'Background Video Title' => __('Dekoratives Hintergrundvideo', 'restatify-base'),
        'Background Video Pause' => __('Hintergrundvideo pausieren', 'restatify-base'),
        'Background Video Play' => __('Hintergrundvideo abspielen', 'restatify-base'),
        'Background Video Error' => __('Das Hintergrundvideo konnte nicht abgespielt werden.', 'restatify-base'),
        'Header CTA Label' => trim((string) get_theme_mod('restatify_cta_button_label', __('Start now', 'restatify-base'))),
        'Footer Slogan' => trim((string) get_theme_mod('restatify_footer_title', __('Strategie, die mit Ihrem Unternehmen mitwaechst.', 'restatify-base'))),
        'Footer Description' => trim((string) get_theme_mod('restatify_footer_description', __('Wir unterstuetzen Sie bei Positionierung, Wachstum und Umsetzung - strukturiert, messbar und hands-on.', 'restatify-base'))),
        'Footer vCard Text' => trim((string) get_theme_mod('restatify_footer_vcard_text', __('vCard Gruender', 'restatify-base'))),
        'Blog Overview Link' => __('Zur Blog-Übersicht', 'restatify-base'),
        'Blog Navigation Open' => __('Artikelübersicht öffnen', 'restatify-base'),
        'Blog Navigation Heading' => __('Alle Blogartikel', 'restatify-base'),
        'Blog Navigation Close' => __('Artikelübersicht schließen', 'restatify-base'),
        'Blog Navigation Label' => __('Blog-Navigation', 'restatify-base'),
        'Blog Navigation Pagination Label' => __('Artikellisten-Seiten', 'restatify-base'),
        'Blog Navigation Previous Page' => __('Vorherige Artikel', 'restatify-base'),
        'Blog Navigation Next Page' => __('Weitere Artikel', 'restatify-base'),
        'Blog Navigation Page Status' => __('Seite %1$d von %2$d', 'restatify-base'),
        'Blog Navigation Empty State' => __('Es sind noch keine Artikel veröffentlicht.', 'restatify-base'),
        'Blog Post Navigation Label' => __('Artikelnavigation', 'restatify-base'),
        'Blog Previous Post' => __('Vorheriger Artikel', 'restatify-base'),
        'Blog Next Post' => __('Nächster Artikel', 'restatify-base'),
        'Blog Grid Loading' => __('Weitere Artikel werden geladen …', 'restatify-base'),
        'Blog Grid End' => __('Alle Artikel sind geladen.', 'restatify-base'),
        'Blog Grid Error' => __('Weitere Artikel konnten nicht geladen werden.', 'restatify-base'),
        'Blog Grid Retry' => __('Erneut versuchen', 'restatify-base'),
        'Blog Grid Unsupported' => __('Bitte verwende einen aktuellen Browser, um weitere Artikel automatisch zu laden.', 'restatify-base'),
        'Blog Grid JavaScript Required' => __('Aktiviere JavaScript, um beim Scrollen weitere Blogartikel zu laden.', 'restatify-base'),
        'Comment Security Verification Failure' => __('Die Sicherheitsprüfung konnte nicht abgeschlossen werden. Bitte versuche es erneut.', 'restatify-base'),
        'Comment Security Google Disclosure' => __('Der Spam-Schutz wird von Google reCAPTCHA bereitgestellt. Es gelten Googles Datenschutzerklärung (%1$s) und Nutzungsbedingungen (%2$s). Google kann IP-Adresse und Prüfdaten zur Spamabwehr verarbeiten.', 'restatify-base'),
        'Comment Security Cloudflare Disclosure' => __('Der Spam-Schutz wird von Cloudflare Turnstile bereitgestellt. Es gelten Cloudflares Datenschutzrichtlinie (%1$s) und Nutzungsbedingungen (%2$s). Cloudflare kann IP-Adresse und Prüfdaten zur Spamabwehr verarbeiten.', 'restatify-base'),
        'Comment Security Privacy Link' => __('Datenschutzerklärung', 'restatify-base'),
        'Comment Security Terms Link' => __('Nutzungsbedingungen', 'restatify-base'),
        'Footer vCard URL' => trim((string) get_theme_mod('restatify_footer_vcard_url', '')),
        'Footer Badge 1 URL' => trim((string) get_theme_mod('restatify_footer_trust_badge_1_url', '')),
        'Footer Badge 2 URL' => trim((string) get_theme_mod('restatify_footer_trust_badge_2_url', '')),
        'Footer Badge 3 URL' => trim((string) get_theme_mod('restatify_footer_trust_badge_3_url', '')),
    ];

    $footer_column_defaults = restatify_get_footer_column_defaults();

    for ($column_index = 1; $column_index <= 3; $column_index++) {
        $default_title = (string) ($footer_column_defaults[$column_index]['title'] ?? '');
        $strings['Footer Column ' . $column_index . ' Title'] = trim((string) get_theme_mod('restatify_footer_col_' . $column_index . '_title', $default_title));

        for ($link_index = 1; $link_index <= 4; $link_index++) {
            $default_link = (array) ($footer_column_defaults[$column_index]['links'][$link_index - 1] ?? []);
            $default_link_title = (string) ($default_link['title'] ?? '');
            $default_link_url = (string) ($default_link['url'] ?? '');

            $strings['Footer Column ' . $column_index . ' Link ' . $link_index . ' Title'] = trim((string) get_theme_mod('restatify_footer_col_' . $column_index . '_link_' . $link_index . '_title', $default_link_title));
            $strings['Footer Column ' . $column_index . ' Link ' . $link_index . ' URL'] = trim((string) get_theme_mod('restatify_footer_col_' . $column_index . '_link_' . $link_index . '_url', $default_link_url));
        }
    }

    foreach ($strings as $name => $value) {
        if ($value !== '') {
            pll_register_string($name, $value, 'Restatify Theme');
        }
    }
}
add_action('init', 'restatify_register_polylang_strings');
